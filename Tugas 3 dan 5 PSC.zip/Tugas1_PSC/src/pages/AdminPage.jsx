import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "../components/atoms";
import { Header, Sidebar, Footer } from "../components/organisms";
import StudentFormModal from "../components/organisms/StudentFormModal";
import Notification from "../components/organisms/Notification";

const AdminPage = () => {
  const navigate = useNavigate();
  const [showModal, setShowModal] = useState(false);
  const [students, setStudents] = useState([
    { nim: "20211002", name: "Siti Aminah", major: "Teknik Informatika" },
    { nim: "20211003", name: "Budi Santoso", major: "Sistem Informasi" },
  ]);
  const [formData, setFormData] = useState({ nim: "", name: "", major: "" });
  const [editingIndex, setEditingIndex] = useState(null);
  const [notification, setNotification] = useState(null);

  const sidebarItems = [
    { icon: "🏠", label: "Dashboard", href: "#" },
    { icon: "🎓", label: "Mahasiswa", href: "#" },
    { icon: "📊", label: "Laporan", href: "#" },
  ];

  const handleLogout = () => {
    navigate("/");
  };

  const openModal = () => {
    setFormData({ nim: "", name: "", major: "" });
    setEditingIndex(null);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setFormData({ nim: "", name: "", major: "" });
    setEditingIndex(null);
  };

  const handleSaveStudent = (data) => {
    if (editingIndex !== null) {
      const updatedStudents = [...students];
      updatedStudents[editingIndex] = data;
      setStudents(updatedStudents);
      setNotification({
        message: "Data mahasiswa berhasil diperbarui!",
        type: "success",
      });
    } else {
      setStudents([...students, data]);
      setNotification({
        message: "Mahasiswa baru berhasil ditambahkan!",
        type: "success",
      });
    }

    closeModal();
  };

  const handleEditStudent = (index) => {
    setFormData(students[index]);
    setEditingIndex(index);
    setShowModal(true);
  };

  const handleDeleteStudent = (index) => {
    const studentName = students[index].name;
    if (
      window.confirm(
        `Apakah Anda yakin ingin menghapus data ${studentName}? Aksi ini tidak dapat dibatalkan.`,
      )
    ) {
      setStudents(students.filter((_, i) => i !== index));
      setNotification({
        message: `Data ${studentName} berhasil dihapus!`,
        type: "success",
      });
    }
  };

  return (
    <div className="flex h-screen">
      <Sidebar items={sidebarItems} active="Mahasiswa" />

      <div className="flex flex-col flex-1">
        <Header title="Daftar Mahasiswa" onLogout={handleLogout} />

        <main className="flex-1 p-6 overflow-auto bg-gray-100">
          <div className="bg-white shadow rounded-lg p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-semibold text-gray-800">
                Data Mahasiswa
              </h2>
              <Button
                variant="primary"
                onClick={openModal}
                className="flex items-center space-x-2"
              >
                + Tambah Mahasiswa
              </Button>
            </div>

            {students.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <p>Tidak ada data mahasiswa</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-gray-700">
                  <thead className="bg-blue-600 text-white">
                    <tr>
                      <th className="py-3 px-4 text-left">NIM</th>
                      <th className="py-3 px-4 text-left">Nama</th>
                      <th className="py-3 px-4 text-left">Jurusan</th>
                      <th className="py-3 px-4 text-center">Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                    {students.map((student, index) => (
                      <tr
                        key={index}
                        className="even:bg-gray-100 odd:bg-white border-b hover:bg-gray-50"
                      >
                        <td className="py-3 px-4">{student.nim}</td>
                        <td className="py-3 px-4">{student.name}</td>
                        <td className="py-3 px-4">{student.major}</td>
                        <td className="py-3 px-4 text-center space-x-2 flex justify-center">
                          <Button
                            variant="warning"
                            className="px-3 py-1 text-sm"
                            onClick={() => handleEditStudent(index)}
                          >
                            Edit
                          </Button>
                          <Button
                            variant="danger"
                            className="px-3 py-1 text-sm"
                            onClick={() => handleDeleteStudent(index)}
                          >
                            Hapus
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            <div className="mt-6 pt-6 border-t text-sm text-gray-600">
              <p>
                Total Mahasiswa: <strong>{students.length}</strong>
              </p>
            </div>
          </div>
        </main>

        <Footer />
      </div>

      {/* Modal for Add/Edit */}
      <StudentFormModal
        isOpen={showModal}
        onClose={closeModal}
        onConfirm={handleSaveStudent}
        initialData={formData}
        isEditing={editingIndex !== null}
        existingNims={students.map((s) => s.nim)}
      />

      {/* Notification */}
      {notification && (
        <Notification message={notification.message} type={notification.type} />
      )}
    </div>
  );
};

export default AdminPage;
